package cl.israel.facturacion_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "servicio-citas", url = "http://localhost:8083")
public interface CitaClient {
    
    @GetMapping("/api/citas/{id}")
    Object obtenerCita(@PathVariable("id") Long id);
}