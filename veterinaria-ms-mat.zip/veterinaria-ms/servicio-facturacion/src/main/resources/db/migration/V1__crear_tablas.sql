CREATE TABLE facturas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_cita BIGINT NOT NULL,
    monto_total DOUBLE NOT NULL,
    fecha_emision TIMESTAMP NOT NULL,
    estado VARCHAR(20),
    metodo_pago VARCHAR(30),
    
    INDEX idx_id_cita (id_cita),
    INDEX idx_estado (estado)
);