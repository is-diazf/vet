package cl.israel.citas.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Data
@Table(name = "citas")
public class Citas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "idveterinario")
    private Long idVeterinario;

    @Column(name = "nombre_mascota")
    private String nombreMascota;

    @Column(name = "raza_mascota")
    private String razaMascota;

    @Column(name = "nombre_dueño")
    private String nombreDueño;

    @Column(name = "telefono_dueño")
    private String telefonoDueño;
    
    @Column(name = "fecha_cita")
    private LocalDate fechaCita;

    @Column(name = "hora_cita")
    private LocalTime horaCita;

    @Column(name = "motivo_cita")
    private String motivoCita;
}
