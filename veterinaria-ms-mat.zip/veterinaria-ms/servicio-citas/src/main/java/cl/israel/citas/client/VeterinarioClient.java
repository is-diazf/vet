package cl.israel.citas.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import cl.israel.citas.dto.VeterinarioDTO;

@FeignClient(name = "veterinario-service", url = "http://localhost:8082/api/veterinarios")
public interface VeterinarioClient {

    @GetMapping("/{id}")
    VeterinarioDTO obtenerVeterinario(@PathVariable("id") Long id);

}
