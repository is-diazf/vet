package cl.israel.historiales_service.model;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "historiales")
@Schema(description = "Representa un historial clínico en el sistema veterinario")
public class Historiales {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del historial", example = "1", required = true)
    private Long id;

    @Column(name = "nombre_mascota", nullable = false)
    @NotBlank(message = "Por favor ingrese el nombre de la mascota")
    @Schema(description = "Nombre de la mascota", example = "Firulais", required = true)
    private String nombreMascota;

    @Column(name = "nombre_doctor", nullable = false)
    @NotBlank(message = "Ingrese el nombre del doctor asignado")
    @Schema(description = "Nombre del doctor asignado", example = "Dr. Pérez", required = true)
    private String nombreDoctor;

    @Column(name = "fecha_visita", nullable = false)
    @NotNull(message = "La fecha de visita es obligatoria")
    @Schema(description = "Fecha de la visita", example = "2025-06-18", required = true)
    private LocalDate fechaVisita;
    
    @Column(length = 500, nullable = false)
    @NotBlank(message = "Ingrese el diagnóstico")
    @Schema(description = "Diagnóstico del veterinario", example = "Infección respiratoria", required = true)
    private String diagnostico;
}
