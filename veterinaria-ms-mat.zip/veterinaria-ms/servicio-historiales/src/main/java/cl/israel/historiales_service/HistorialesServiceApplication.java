package cl.israel.historiales_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HistorialesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistorialesServiceApplication.class, args);
	}

}
