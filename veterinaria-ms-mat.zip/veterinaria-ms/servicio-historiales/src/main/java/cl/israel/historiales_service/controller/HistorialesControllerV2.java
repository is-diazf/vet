package cl.israel.historiales_service.controller;

import cl.israel.historiales_service.dto.HistorialesResponseDTO;
import cl.israel.historiales_service.model.Historiales;
import cl.israel.historiales_service.service.HistorialesService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/historiales")
public class HistorialesControllerV2 {

    private final HistorialesService historialesService;

    public HistorialesControllerV2(HistorialesService historialesService) {
        this.historialesService = historialesService;
    }

    @GetMapping
    public List<HistorialesResponseDTO> getHistoriales() {
        return historialesService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public HistorialesResponseDTO getHistorialById(@PathVariable Long id) {
        return historialesService.obtenerPorId(id);
    }

    @GetMapping("/mascota/{nombreMascota}")
    public List<HistorialesResponseDTO> getHistorialesByMascota(@PathVariable String nombreMascota) {
        return historialesService.obtenerPorMascota(nombreMascota);
    }

    @GetMapping("/doctor/{nombreDoctor}")
    public List<HistorialesResponseDTO> getHistorialesByDoctor(@PathVariable String nombreDoctor) {
        return historialesService.obtenerPorDoctor(nombreDoctor);
    }

    @PostMapping
    public HistorialesResponseDTO saveHistorial(@RequestBody Historiales historial) {
        return historialesService.guardar(historial);
    }

    @PutMapping("/{id}")
    public HistorialesResponseDTO updateHistorialById(@PathVariable Long id, @RequestBody Historiales historial) {
        return historialesService.actualizar(id, historial);
    }

    @DeleteMapping("/{id}")
    public String deleteHistorialById(@PathVariable Long id) {
        historialesService.eliminar(id);
        return "Historial eliminado correctamente";
    }
}