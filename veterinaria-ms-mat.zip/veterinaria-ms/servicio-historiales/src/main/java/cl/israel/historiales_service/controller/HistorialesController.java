package cl.israel.historiales_service.controller;

import cl.israel.historiales_service.dto.HistorialesResponseDTO;
import cl.israel.historiales_service.model.Historiales;
import cl.israel.historiales_service.service.HistorialesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Historiales", description = "Operaciones relacionadas con el historial clínico de mascotas")
@RestController
@RequestMapping("/api/v1/historiales")
public class HistorialesController {

    private final HistorialesService historialesService;

    public HistorialesController(HistorialesService historialesService) {
        this.historialesService = historialesService;
    }

    @GetMapping
    @Operation(summary = "Obtener todos los historiales", description = "Obtiene una lista de todos los historiales clínicos registrados")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de historiales obtenida exitosamente",
                content = @Content(mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = HistorialesResponseDTO.class)))),
        @ApiResponse(responseCode = "404", description = "No se encontraron historiales", content = @Content),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<HistorialesResponseDTO> getHistoriales() {
        return historialesService.obtenerTodos();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un historial por ID", description = "Retorna un historial clínico específico basado en su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Historial encontrado",
                content = @Content(mediaType = "application/json",
                schema = @Schema(implementation = HistorialesResponseDTO.class))),
        @ApiResponse(responseCode = "404", description = "Historial no encontrado", content = @Content),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public HistorialesResponseDTO getHistorialById(
            @Parameter(description = "ID del historial a buscar", example = "1", required = true)
            @PathVariable Long id) {
        return historialesService.obtenerTodos().stream()
                .filter(historial -> id != null && id.equals(historial.getId()))
                .findFirst()
                .orElse(null);
    }

    @GetMapping("/mascota/{nombreMascota}")
    @Operation(summary = "Buscar historiales por nombre de mascota",
            description = "Retorna todos los historiales de una mascota específica.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Historiales encontrados",
                content = @Content(mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = HistorialesResponseDTO.class)))),
        @ApiResponse(responseCode = "404", description = "No se encontraron historiales", content = @Content)
    })
    public List<HistorialesResponseDTO> getHistorialesByMascota(
            @Parameter(description = "Nombre de la mascota", example = "Firulais", required = true)
            @PathVariable String nombreMascota) {
        return historialesService.obtenerPorMascota(nombreMascota);
    }

    @GetMapping("/doctor/{nombreDoctor}")
    @Operation(summary = "Buscar historiales por nombre del doctor",
            description = "Retorna todos los historiales atendidos por un doctor específico.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Historiales encontrados",
                content = @Content(mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = HistorialesResponseDTO.class)))),
        @ApiResponse(responseCode = "404", description = "No se encontraron historiales", content = @Content)
    })
    public List<HistorialesResponseDTO> getHistorialesByDoctor(
            @Parameter(description = "Nombre del doctor", example = "Dr. Pérez", required = true)
            @PathVariable String nombreDoctor) {
        return historialesService.obtenerPorDoctor(nombreDoctor);
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo historial", description = "Agrega un nuevo historial clínico al sistema.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Historial creado exitosamente",
                content = @Content(mediaType = "application/json",
                schema = @Schema(implementation = HistorialesResponseDTO.class))),
        @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public HistorialesResponseDTO saveHistorial(@RequestBody Historiales historial) {
        return historialesService.guardar(historial);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un historial existente",
            description = "Actualiza los datos de un historial clínico existente por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Historial actualizado exitosamente",
                content = @Content(mediaType = "application/json",
                schema = @Schema(implementation = HistorialesResponseDTO.class))),
        @ApiResponse(responseCode = "404", description = "Historial no encontrado", content = @Content),
        @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public HistorialesResponseDTO updateHistorialById(
            @Parameter(description = "ID del historial a actualizar", example = "1", required = true)
            @PathVariable Long id,
            @RequestBody Historiales historial) {
        return historialesService.actualizar(id, historial);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un historial", description = "Elimina un historial clínico del sistema por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Historial eliminado exitosamente",
                content = @Content(mediaType = "text/plain")),
        @ApiResponse(responseCode = "404", description = "Historial no encontrado", content = @Content)
    })
    public String deleteHistorialById(
            @Parameter(description = "ID del historial a eliminar", example = "1", required = true)
            @PathVariable Long id) {
        historialesService.eliminar(id);
        return "Historial eliminado correctamente";
    }
}