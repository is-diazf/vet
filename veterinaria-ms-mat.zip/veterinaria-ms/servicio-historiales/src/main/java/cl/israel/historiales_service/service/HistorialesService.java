package cl.israel.historiales_service.service;

import cl.israel.historiales_service.dto.HistorialesResponseDTO;
import cl.israel.historiales_service.model.Historiales;
import cl.israel.historiales_service.repository.HistorialRepository;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class HistorialesService {

    private final HistorialRepository historialRepository;

    // Obtener todos los historiales
    public List<HistorialesResponseDTO> obtenerTodos() {
        List<Historiales> historiales = historialRepository.findAll();
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

    public HistorialesResponseDTO obtenerPorId(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser nulo");
        }
        Historiales historial = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Historial no encontrado con id: " + id));
        return mapearDto(historial);
    }

    public List<HistorialesResponseDTO> obtenerPorMascota(String nombreMascota) {
        List<Historiales> historiales = historialRepository.findByNombreMascota(nombreMascota);
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

    public List<HistorialesResponseDTO> obtenerPorDoctor(String nombreDoctor) {
        List<Historiales> historiales = historialRepository.findByNombreDoctor(nombreDoctor);
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

    public HistorialesResponseDTO guardar(Historiales historial) {
        if (historial == null) {
            throw new IllegalArgumentException("El historial no puede ser null");
        }
        Historiales historialGuardado = historialRepository.save(historial);
        return mapearDto(historialGuardado);
    }

    public HistorialesResponseDTO actualizar(Long id, Historiales detallesHistorial) {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser nulo");
        }
        Historiales historialExistente = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Historial no encontrado con ese id: " + id));

        historialExistente.setNombreMascota(detallesHistorial.getNombreMascota());
        historialExistente.setNombreDoctor(detallesHistorial.getNombreDoctor());
        historialExistente.setFechaVisita(detallesHistorial.getFechaVisita());
        historialExistente.setDiagnostico(detallesHistorial.getDiagnostico());

        Historiales historialActualizado = historialRepository.save(historialExistente);
        return mapearDto(historialActualizado);
    }

    public void eliminar(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser null");
        }

        Historiales historiales = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("No hay historial con ese id: " + id));

        historialRepository.delete(Objects.requireNonNull(historiales));
    }

    private HistorialesResponseDTO mapearDto(Historiales historial) {
        HistorialesResponseDTO dto = new HistorialesResponseDTO();
        dto.setId(historial.getId());
        dto.setNombreMascota(historial.getNombreMascota());
        dto.setNombreDoctor(historial.getNombreDoctor());
        dto.setFechaVisita(historial.getFechaVisita());
        dto.setDiagnostico(historial.getDiagnostico());
        return dto;
    }
}