package cl.israel.historiales_service.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class HistorialesResponseDTO {

    private Long id;
    private String nombreMascota;
    private String nombreDoctor;
    private LocalDate fechaVisita;
    private String diagnostico;

}
