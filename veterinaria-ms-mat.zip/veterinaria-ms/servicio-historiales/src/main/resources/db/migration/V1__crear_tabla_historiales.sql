CREATE TABLE histories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre_mascota VARCHAR(100) NOT NULL,
    nombre_doctor VARCHAR(100) NOT NULL,
    fecha_visita DATE NOT NULL,
    diagnostico VARCHAR(500) NOT NULL
);