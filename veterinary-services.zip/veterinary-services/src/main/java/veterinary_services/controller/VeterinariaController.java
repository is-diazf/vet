package veterinary_services.controller;

import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.model.Veterinaria;
import veterinary_services.service.VeterinariaService;
import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.HttpStatus;

@ResponseStatus
@RestController
@RequestMapping("/api/v1/veterinarias")
@RequiredArgsConstructor
public class VeterinariaController {

    private final VeterinariaService veterinariaService;


    //metodo para obtener una veterinaria por id
    @GetMapping("/{id}")
    public VeterinariaResponseDTO obtenerVeterinaria(@PathVariable Long id) {
        return veterinariaService.obtenerVeterinaria(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public VeterinariaResponseDTO guardarVeterinaria(@RequestBody VeterinariaRequestDTO veterinariaRequestDTO) {
        return veterinariaService.guardarVeterinaria(veterinariaRequestDTO);
    }
}
