package cl.israel.recetas.service;

import cl.israel.recetas.model.Receta;
import cl.israel.recetas.repository.RecetaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecetaService {

    private final RecetaRepository recetaRepository;

    public RecetaService(RecetaRepository recetaRepository) {
        this.recetaRepository = recetaRepository;
    }

    public List<Receta> getRecetas() {
        return recetaRepository.getRecetas();
    }

    public Receta saveReceta(Receta receta) {
        return recetaRepository.saveReceta(receta);
    }

    public Receta getRecetaById(int id) {
        return recetaRepository.searchById(id);
    }

    public Receta updateReceta(Receta receta) {
        return recetaRepository.updateReceta(receta);
    }

    public String deleteReceta(int id) {
        recetaRepository.eliminar(id);
        return "Receta eliminada correctamente";
    }
}