package cl.israel.recetas.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa una receta médica")
public class Receta {

    @Schema(description = "ID único de la receta", example = "1", required = true)
    private int id;

    @Schema(description = "ID del historial asociado", example = "1", required = true)
    private long idHistorial;

    @Schema(description = "ID de la mascota", example = "1", required = true)
    private long idMascota;

    @Schema(description = "Nombre del medicamento", example = "Amoxicilina 500mg", required = true)
    private String medicamento;

    @Schema(description = "Dosis del medicamento", example = "1 tableta cada 8 horas")
    private String dosis;

    @Schema(description = "Duración en días del tratamiento", example = "7")
    private Integer duracionDias;

    @Schema(description = "Indicaciones adicionales", example = "Tomar con comida")
    private String indicaciones;
}