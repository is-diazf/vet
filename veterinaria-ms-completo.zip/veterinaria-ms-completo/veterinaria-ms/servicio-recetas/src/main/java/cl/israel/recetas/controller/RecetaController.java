package cl.israel.recetas.controller;

import cl.israel.recetas.model.Receta;
import cl.israel.recetas.service.RecetaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/recetas")
@Tag(name = "Recetas", description = "Operaciones relacionadas con las recetas médicas")
public class RecetaController {

    private final RecetaService recetaService;

    public RecetaController(RecetaService recetaService) {
        this.recetaService = recetaService;
    }

    @GetMapping
    @Operation(summary = "Obtener todas las recetas", description = "Obtiene una lista de todas las recetas registradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de recetas obtenida exitosamente", 
                    content = @Content(mediaType = "application/json", 
                    array = @ArraySchema(schema = @Schema(implementation = Receta.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<Receta> getRecetas() {
        return recetaService.getRecetas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una receta por ID", description = "Retorna una receta específica basada en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Receta encontrada", 
                    content = @Content(mediaType = "application/json", 
                    schema = @Schema(implementation = Receta.class))),
            @ApiResponse(responseCode = "404", description = "Receta no encontrada", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public Receta getRecetaById(
            @Parameter(description = "ID de la receta a buscar", example = "1", required = true) 
            @PathVariable int id) {
        return recetaService.getRecetaById(id);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva receta", description = "Agrega una nueva receta al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Receta creada exitosamente", 
                    content = @Content(mediaType = "application/json", 
                    schema = @Schema(implementation = Receta.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public Receta saveReceta(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Receta que se va a crear", 
                    required = true, 
                    content = @Content(mediaType = "application/json", 
                    schema = @Schema(implementation = Receta.class), 
                    examples = @ExampleObject(name = "Ejemplo de receta", value = """
                            {
                                "id": 1,
                                "idHistorial": 1,
                                "idMascota": 1,
                                "medicamento": "Amoxicilina 500mg",
                                "dosis": "1 tableta cada 8 horas",
                                "duracionDias": 7,
                                "indicaciones": "Tomar con comida"
                            }
                            """))) 
            @RequestBody Receta receta) {
        return recetaService.saveReceta(receta);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una receta existente", description = "Actualiza los datos de una receta existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Receta actualizada exitosamente", 
                    content = @Content(mediaType = "application/json", 
                    schema = @Schema(implementation = Receta.class))),
            @ApiResponse(responseCode = "404", description = "Receta no encontrada", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public Receta updateRecetaById(
            @Parameter(description = "ID de la receta a actualizar", example = "1", required = true) 
            @PathVariable int id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Receta con los datos actualizados", 
                    required = true, 
                    content = @Content(mediaType = "application/json", 
                    schema = @Schema(implementation = Receta.class), 
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "id": 1,
                                "idHistorial": 1,
                                "idMascota": 1,
                                "medicamento": "Amoxicilina 500mg",
                                "dosis": "1 tableta cada 12 horas",
                                "duracionDias": 10,
                                "indicaciones": "Tomar con comida y abundante agua"
                            }
                            """))) 
            @RequestBody Receta receta) {
        receta.setId(id);
        return recetaService.updateReceta(receta);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una receta", description = "Elimina una receta del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Receta eliminada exitosamente", 
                    content = @Content(mediaType = "text/plain", 
                    examples = @ExampleObject(value = "Receta eliminada correctamente"))),
            @ApiResponse(responseCode = "404", description = "Receta no encontrada", content = @Content)
    })
    public String deleteRecetaById(
            @Parameter(description = "ID de la receta a eliminar", example = "1", required = true) 
            @PathVariable int id) {
        return recetaService.deleteReceta(id);
    }
}