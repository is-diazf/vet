package cl.israel.recetas.repository;

import cl.israel.recetas.model.Receta;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.ArrayList;

@Repository
public class RecetaRepository {

    private List<Receta> listaRecetas = new ArrayList<>();

    public List<Receta> getRecetas() {
        return listaRecetas;
    }

    public Receta searchById(int id) {
        for (Receta receta : listaRecetas) {
            if (receta.getId() == id) {
                return receta;
            }
        }
        return null;
    }

    public Receta buscarPorMedicamento(String medicamento) {
        for (Receta receta : listaRecetas) {
            if (receta.getMedicamento().equals(medicamento)) {
                return receta;
            }
        }
        return null;
    }

    public Receta saveReceta(Receta receta) {
        listaRecetas.add(receta);
        return receta;
    }

    public Receta updateReceta(Receta receta) {
        int idPosicion = -1;

        for (int i = 0; i < listaRecetas.size(); i++) {
            if (listaRecetas.get(i).getId() == receta.getId()) {
                idPosicion = i;
                break;
            }
        }

        if (idPosicion == -1) {
            return null;
        }

        Receta recetaExistente = listaRecetas.get(idPosicion);
        recetaExistente.setId(receta.getId());
        recetaExistente.setIdHistorial(receta.getIdHistorial());
        recetaExistente.setIdMascota(receta.getIdMascota());
        recetaExistente.setMedicamento(receta.getMedicamento());
        recetaExistente.setDosis(receta.getDosis());
        recetaExistente.setDuracionDias(receta.getDuracionDias());
        recetaExistente.setIndicaciones(receta.getIndicaciones());

        return recetaExistente;
    }

    public void eliminar(int id) {
        listaRecetas.removeIf(x -> x.getId() == id);
    }
}