package cl.israel.recetas.controller;

import cl.israel.recetas.model.Receta;
import cl.israel.recetas.service.RecetaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/recetas")
public class RecetaControllerV2 {

    private final RecetaService recetaService;

    public RecetaControllerV2(RecetaService recetaService) {
        this.recetaService = recetaService;
    }

    @GetMapping
    public List<Receta> getRecetas() {
        return recetaService.getRecetas();
    }

    @GetMapping("/{id}")
    public Receta getRecetaById(@PathVariable int id) {
        return recetaService.getRecetaById(id);
    }

    @PostMapping
    public Receta saveReceta(@RequestBody Receta receta) {
        return recetaService.saveReceta(receta);
    }

    @PutMapping("/{id}")
    public Receta updateRecetaById(@PathVariable int id, @RequestBody Receta receta) {
        receta.setId(id);
        return recetaService.updateReceta(receta);
    }

    @DeleteMapping("/{id}")
    public String deleteRecetaById(@PathVariable int id) {
        return recetaService.deleteReceta(id);
    }
}