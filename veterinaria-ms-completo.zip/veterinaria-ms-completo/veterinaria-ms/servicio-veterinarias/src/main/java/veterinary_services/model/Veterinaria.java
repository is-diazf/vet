package veterinary_services.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  
@NoArgsConstructor   
@Entity
@Table(name = "veterinarias")
@Schema(description = "Entidad que representa una veterinaria (local)")  
public class Veterinaria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID único de la veterinaria", example = "1", required = true)  
    private Long id;

    @NotBlank(message = "El nombre del local es obligatorio")
    @Size(max = 100, message = "El nombre no puede tener más de 100 caracteres")
    @Schema(description = "Nombre de la veterinaria", example = "Veterinaria Central", required = true)  
    private String nombre;

    @NotBlank(message = "La dirección es obligatoria")
    @Size(max = 200, message = "La dirección no puede tener más de 200 caracteres")
    @Schema(description = "Dirección de la veterinaria", example = "Av. Los Pinos 123", required = true)  
    private String direccion;

    @NotBlank(message = "El número de teléfono es obligatorio")
    @Size(max = 15, message = "El número de teléfono no puede tener más de 15 dígitos")
    @Schema(description = "Teléfono de contacto", example = "+56912345678", required = true)  
    private String telefono;
}