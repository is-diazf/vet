package veterinary_services.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.model.Veterinaria;
import veterinary_services.repository.VeterinariaRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class VeterinariaService {

    private final VeterinariaRepository veterinariaRepository;

    public VeterinariaService(VeterinariaRepository veterinariaRepository) {
        this.veterinariaRepository = veterinariaRepository;
    }

    public List<VeterinariaResponseDTO> getVeterinarias() {
        return veterinariaRepository.findAll()
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public VeterinariaResponseDTO saveVeterinaria(VeterinariaRequestDTO requestDTO) {
        Veterinaria veterinaria = toEntity(requestDTO);
        Veterinaria saved = veterinariaRepository.save(veterinaria);
        return toResponseDTO(saved);
    }

    public VeterinariaResponseDTO getVeterinariaById(Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        return toResponseDTO(veterinaria);
    }

    public VeterinariaResponseDTO updateVeterinaria(VeterinariaRequestDTO requestDTO, Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        
        veterinaria.setNombre(requestDTO.getNombre());
        veterinaria.setDireccion(requestDTO.getDireccion());
        veterinaria.setTelefono(requestDTO.getTelefono());
        
        Veterinaria updated = veterinariaRepository.save(veterinaria);
        return toResponseDTO(updated);
    }

    public String deleteVeterinaria(Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        veterinariaRepository.delete(veterinaria);
        return "Veterinaria eliminada correctamente";
    }

    private VeterinariaResponseDTO toResponseDTO(Veterinaria veterinaria) {
        VeterinariaResponseDTO dto = new VeterinariaResponseDTO();
        dto.setId(veterinaria.getId());
        dto.setNombre(veterinaria.getNombre());
        dto.setDireccion(veterinaria.getDireccion());
        dto.setTelefono(veterinaria.getTelefono());
        return dto;
    }

    private Veterinaria toEntity(VeterinariaRequestDTO requestDTO) {
        Veterinaria veterinaria = new Veterinaria();
        veterinaria.setNombre(requestDTO.getNombre());
        veterinaria.setDireccion(requestDTO.getDireccion());
        veterinaria.setTelefono(requestDTO.getTelefono());
        return veterinaria;
    }
}