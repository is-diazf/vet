package veterinary_services.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import veterinary_services.model.Veterinaria;

@Repository
public interface VeterinariaRepository extends JpaRepository<Veterinaria, Long> {
}