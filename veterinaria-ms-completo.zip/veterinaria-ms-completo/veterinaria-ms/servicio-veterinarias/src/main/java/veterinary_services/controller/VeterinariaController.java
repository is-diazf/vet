package veterinary_services.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.service.VeterinariaService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/veterinarias")
@Tag(name = "Veterinarias", description = "Operaciones relacionadas con las veterinarias")
public class VeterinariaController {

    private final VeterinariaService veterinariaService;

    public VeterinariaController(VeterinariaService veterinariaService) {
        this.veterinariaService = veterinariaService;
    }

    @GetMapping
    @Operation(summary = "Obtener todas las veterinarias", description = "Obtiene una lista de todas las veterinarias registradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de veterinarias obtenida exitosamente",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VeterinariaResponseDTO.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<VeterinariaResponseDTO> getVeterinarias() {
        return veterinariaService.getVeterinarias();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una veterinaria por ID", description = "Retorna una veterinaria específica basada en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Veterinaria encontrada",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = VeterinariaResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Veterinaria no encontrada", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public VeterinariaResponseDTO getVeterinariaById(
            @Parameter(description = "ID de la veterinaria a buscar", example = "1", required = true)
            @PathVariable Long id) {
        return veterinariaService.getVeterinariaById(id);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva veterinaria", description = "Agrega una nueva veterinaria al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Veterinaria creada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = VeterinariaResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public VeterinariaResponseDTO saveVeterinaria(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Veterinaria que se va a crear",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = VeterinariaRequestDTO.class),
                    examples = @ExampleObject(name = "Ejemplo de veterinaria", value = """
                            {
                                "nombre": "Veterinaria Central",
                                "direccion": "Av. Los Pinos 123",
                                "telefono": "+56912345678"
                            }
                            """)))
            @Valid @RequestBody VeterinariaRequestDTO veterinariaRequestDTO) {
        return veterinariaService.saveVeterinaria(veterinariaRequestDTO);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una veterinaria existente", description = "Actualiza los datos de una veterinaria existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Veterinaria actualizada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = VeterinariaResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Veterinaria no encontrada", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public VeterinariaResponseDTO updateVeterinariaById(
            @Parameter(description = "ID de la veterinaria a actualizar", example = "1", required = true)
            @PathVariable Long id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Veterinaria con los datos actualizados",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = VeterinariaRequestDTO.class),
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "nombre": "Veterinaria Central Actualizada",
                                "direccion": "Av. Los Pinos 456",
                                "telefono": "+56998765432"
                            }
                            """)))
            @Valid @RequestBody VeterinariaRequestDTO veterinariaRequestDTO) {
        return veterinariaService.updateVeterinaria(veterinariaRequestDTO, id);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una veterinaria", description = "Elimina una veterinaria del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Veterinaria eliminada exitosamente",
                    content = @Content(mediaType = "text/plain",
                    examples = @ExampleObject(value = "Veterinaria eliminada correctamente"))),
            @ApiResponse(responseCode = "404", description = "Veterinaria no encontrada", content = @Content)
    })
    public String deleteVeterinariaById(
            @Parameter(description = "ID de la veterinaria a eliminar", example = "1", required = true)
            @PathVariable Long id) {
        veterinariaService.deleteVeterinaria(id);
        return "Veterinaria eliminada correctamente";
    }
}
