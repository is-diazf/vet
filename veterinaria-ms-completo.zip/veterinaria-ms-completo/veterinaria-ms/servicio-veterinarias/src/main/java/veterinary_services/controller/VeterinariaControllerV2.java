package veterinary_services.controller;

import org.springframework.web.bind.annotation.*;
import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.service.VeterinariaService;

import java.util.List;

@RestController
@RequestMapping("/api/v2/veterinarias")
public class VeterinariaControllerV2 {

    private final VeterinariaService veterinariaService;

    public VeterinariaControllerV2(VeterinariaService veterinariaService) {
        this.veterinariaService = veterinariaService;
    }

    @GetMapping
    public List<VeterinariaResponseDTO> getVeterinarias() {
        return veterinariaService.getVeterinarias();
    }

    @GetMapping("/{id}")
    public VeterinariaResponseDTO getVeterinariaById(@PathVariable Long id) {
        return veterinariaService.getVeterinariaById(id);
    }

    @PostMapping
    public VeterinariaResponseDTO saveVeterinaria(@RequestBody VeterinariaRequestDTO veterinariaRequestDTO) {
        return veterinariaService.saveVeterinaria(veterinariaRequestDTO);
    }

    @PutMapping("/{id}")
    public VeterinariaResponseDTO updateVeterinariaById(@PathVariable Long id, @RequestBody VeterinariaRequestDTO veterinariaRequestDTO) {
        return veterinariaService.updateVeterinaria(veterinariaRequestDTO, id);
    }

    @DeleteMapping("/{id}")
    public String deleteVeterinariaById(@PathVariable Long id) {
        veterinariaService.deleteVeterinaria(id);
        return "Veterinaria eliminada correctamente";
    }
}