package cl.mathias.doctores_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa un doctor")
public class Doctor {

    @Schema(description = "ID único del doctor", example = "1", required = true)
    private int id;

    @Schema(description = "Nombre completo del doctor", example = "Dr. Juan Pérez", required = true)
    private String nombre;

    @Schema(description = "Especialidad del doctor", example = "Cardiología", required = true)
    private String especialidad;
}
