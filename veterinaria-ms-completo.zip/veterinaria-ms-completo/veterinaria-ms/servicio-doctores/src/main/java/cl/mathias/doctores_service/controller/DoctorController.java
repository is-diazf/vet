package cl.mathias.doctores_service.controller;

import cl.mathias.doctores_service.model.Doctor;
import cl.mathias.doctores_service.service.DoctorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/doctores")
@Tag(name = "Doctores", description = "Operaciones relacionadas con los doctores")
public class DoctorController {

    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @GetMapping
    @Operation(summary = "Obtener todos los doctores", description = "Obtiene una lista de todos los doctores registrados.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de doctores obtenida exitosamente",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Doctor.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<Doctor> getDoctores() {
        return doctorService.getDoctores();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un doctor por ID", description = "Retorna un doctor específico basado en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Doctor encontrado",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Doctor.class))),
            @ApiResponse(responseCode = "404", description = "Doctor no encontrado", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public Doctor getDoctorById(
            @Parameter(description = "ID del doctor a buscar", example = "1", required = true)
            @PathVariable int id) {
        return doctorService.getDoctorById(id);
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo doctor", description = "Agrega un nuevo doctor al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Doctor creado exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Doctor.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public Doctor saveDoctor(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Doctor que se va a crear",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Doctor.class),
                    examples = @ExampleObject(name = "Ejemplo de doctor", value = """
                            {
                                "id": 1,
                                "nombre": "Dr. Juan Pérez",
                                "especialidad": "Cardiología"
                            }
                            """)))
            @RequestBody Doctor doctor) {
        return doctorService.saveDoctor(doctor);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un doctor existente", description = "Actualiza los datos de un doctor existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Doctor actualizado exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Doctor.class))),
            @ApiResponse(responseCode = "404", description = "Doctor no encontrado", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public Doctor updateDoctorById(
            @Parameter(description = "ID del doctor a actualizar", example = "1", required = true)
            @PathVariable int id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Doctor con los datos actualizados",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Doctor.class),
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "id": 1,
                                "nombre": "Dr. Juan Pérez",
                                "especialidad": "Cardiología Intervencionista"
                            }
                            """)))
            @RequestBody Doctor doctor) {
        doctor.setId(id);
        return doctorService.updateDoctor(doctor);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un doctor", description = "Elimina un doctor del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Doctor eliminado exitosamente",
                    content = @Content(mediaType = "text/plain")),
            @ApiResponse(responseCode = "404", description = "Doctor no encontrado", content = @Content)
    })
    public String deleteDoctorById(
            @Parameter(description = "ID del doctor a eliminar", example = "1", required = true)
            @PathVariable int id) {
        return doctorService.deleteDoctor(id);
    }
}