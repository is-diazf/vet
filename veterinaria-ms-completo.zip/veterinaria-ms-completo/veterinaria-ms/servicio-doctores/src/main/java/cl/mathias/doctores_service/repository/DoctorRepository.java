package cl.mathias.doctores_service.repository;

import cl.mathias.doctores_service.model.Doctor;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class DoctorRepository {

    private List<Doctor> listaDoctores = new ArrayList<>();

    public List<Doctor> getDoctores() {
        return listaDoctores;
    }

    public Doctor searchById(int id) {
        for (Doctor doctor : listaDoctores) {
            if (doctor.getId() == id) {
                return doctor;
            }
        }
        return null;
    }

    public Doctor buscarPorNombre(String nombre) {
        for (Doctor doctor : listaDoctores) {
            if (doctor.getNombre().equalsIgnoreCase(nombre)) {
                return doctor;
            }
        }
        return null;
    }

    public Doctor buscarPorEspecialidad(String especialidad) {
        for (Doctor doctor : listaDoctores) {
            if (doctor.getEspecialidad().equalsIgnoreCase(especialidad)) {
                return doctor;
            }
        }
        return null;
    }

    public Doctor saveDoctor(Doctor doctor) {
        listaDoctores.add(doctor);
        return doctor;
    }

    public Doctor updateDoctor(Doctor doctor) {
        int idPosicion = -1;
        for (int i = 0; i < listaDoctores.size(); i++) {
            if (listaDoctores.get(i).getId() == doctor.getId()) {
                idPosicion = i;
                break;
            }
        }
        if (idPosicion == -1) {
            return null;
        }
        listaDoctores.set(idPosicion, doctor);
        return doctor;
    }

    public void eliminar(int id) {
        listaDoctores.removeIf(x -> x.getId() == id);
    }
}