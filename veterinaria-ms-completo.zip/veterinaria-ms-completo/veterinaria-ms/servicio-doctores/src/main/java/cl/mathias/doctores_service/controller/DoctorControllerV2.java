package cl.mathias.doctores_service.controller;

import cl.mathias.doctores_service.model.Doctor;
import cl.mathias.doctores_service.service.DoctorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/doctores")
public class DoctorControllerV2 {

    private final DoctorService doctorService;

    public DoctorControllerV2(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @GetMapping
    public List<Doctor> getDoctores() {
        return doctorService.getDoctores();
    }

    @GetMapping("/{id}")
    public Doctor getDoctorById(@PathVariable int id) {
        return doctorService.getDoctorById(id);
    }

    @PostMapping
    public Doctor saveDoctor(@RequestBody Doctor doctor) {
        return doctorService.saveDoctor(doctor);
    }

    @PutMapping("/{id}")
    public Doctor updateDoctorById(@PathVariable int id, @RequestBody Doctor doctor) {
        doctor.setId(id);
        return doctorService.updateDoctor(doctor);
    }

    @DeleteMapping("/{id}")
    public String deleteDoctorById(@PathVariable int id) {
        return doctorService.deleteDoctor(id);
    }
}