package cl.mathias.doctores_service.service;

import cl.mathias.doctores_service.model.Doctor;
import cl.mathias.doctores_service.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public List<Doctor> getDoctores() {
        return doctorRepository.getDoctores();
    }

    public Doctor saveDoctor(Doctor doctor) {
        return doctorRepository.saveDoctor(doctor);
    }

    public Doctor getDoctorById(int id) {
        return doctorRepository.searchById(id);
    }

    public Doctor updateDoctor(Doctor doctor) {
        return doctorRepository.updateDoctor(doctor);
    }

    public String deleteDoctor(int id) {
        doctorRepository.eliminar(id);
        return "Doctor eliminado correctamente";
    }
}