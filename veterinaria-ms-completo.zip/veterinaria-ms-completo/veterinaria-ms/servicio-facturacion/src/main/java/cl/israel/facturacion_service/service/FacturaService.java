package cl.israel.facturacion_service.service;

import cl.israel.facturacion_service.model.Factura;
import cl.israel.facturacion_service.repository.FacturaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacturaService {

    private final FacturaRepository facturaRepository;

    public FacturaService(FacturaRepository facturaRepository) {
        this.facturaRepository = facturaRepository;
    }

    public List<Factura> getFacturas() {
        return facturaRepository.getFacturas();
    }

    public Factura saveFactura(Factura factura) {
        return facturaRepository.saveFactura(factura);
    }

    public Factura getFacturaById(int id) {
        return facturaRepository.searchById(id);
    }

    public Factura updateFactura(Factura factura) {
        return facturaRepository.updateFactura(factura);
    }

    public String deleteFactura(int id) {
        facturaRepository.eliminar(id);
        return "Factura eliminada correctamente";
    }
}