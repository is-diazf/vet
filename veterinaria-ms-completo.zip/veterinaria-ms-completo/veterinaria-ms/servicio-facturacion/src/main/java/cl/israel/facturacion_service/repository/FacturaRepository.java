package cl.israel.facturacion_service.repository;

import cl.israel.facturacion_service.model.Factura;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class FacturaRepository {

    private List<Factura> listaFacturas = new ArrayList<>();

    public List<Factura> getFacturas() {
        return listaFacturas;
    }

    public Factura searchById(int id) {
        for (Factura factura : listaFacturas) {
            if (factura.getId() == id) {
                return factura;
            }
        }
        return null;
    }

    public Factura buscarPorEstado(String estado) {
        for (Factura factura : listaFacturas) {
            if (factura.getEstado().equalsIgnoreCase(estado)) {
                return factura;
            }
        }
        return null;
    }

    public Factura saveFactura(Factura factura) {
        listaFacturas.add(factura);
        return factura;
    }

    public Factura updateFactura(Factura factura) {
        int idPosicion = -1;
        for (int i = 0; i < listaFacturas.size(); i++) {
            if (listaFacturas.get(i).getId() == factura.getId()) {
                idPosicion = i;
                break;
            }
        }
        if (idPosicion == -1) {
            return null;
        }
        listaFacturas.set(idPosicion, factura);
        return factura;
    }

    public void eliminar(int id) {
        listaFacturas.removeIf(x -> x.getId() == id);
    }
}