package cl.israel.facturacion_service.controller;

import cl.israel.facturacion_service.model.Factura;
import cl.israel.facturacion_service.service.FacturaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/facturas")
@Tag(name = "Facturas", description = "Operaciones relacionadas con las facturas")
public class FacturaController {

    private final FacturaService facturaService;

    public FacturaController(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    @GetMapping
    @Operation(summary = "Obtener todas las facturas", description = "Obtiene una lista de todas las facturas registradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de facturas obtenida exitosamente",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Factura.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<Factura> getFacturas() {
        return facturaService.getFacturas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una factura por ID", description = "Retorna una factura específica basada en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Factura encontrada",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Factura.class))),
            @ApiResponse(responseCode = "404", description = "Factura no encontrada", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public Factura getFacturaById(
            @Parameter(description = "ID de la factura a buscar", example = "1", required = true)
            @PathVariable int id) {
        return facturaService.getFacturaById(id);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva factura", description = "Agrega una nueva factura al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Factura creada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Factura.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public Factura saveFactura(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Factura que se va a crear",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Factura.class),
                    examples = @ExampleObject(name = "Ejemplo de factura", value = """
                            {
                                "id": 1,
                                "idCita": 1,
                                "montoTotal": 45000,
                                "fechaEmision": "2025-06-21T10:30:00",
                                "estado": "PAGADA",
                                "metodoPago": "EFECTIVO"
                            }
                            """)))
            @RequestBody Factura factura) {
        return facturaService.saveFactura(factura);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una factura existente", description = "Actualiza los datos de una factura existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Factura actualizada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Factura.class))),
            @ApiResponse(responseCode = "404", description = "Factura no encontrada", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public Factura updateFacturaById(
            @Parameter(description = "ID de la factura a actualizar", example = "1", required = true)
            @PathVariable int id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Factura con los datos actualizados",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Factura.class),
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "id": 1,
                                "idCita": 1,
                                "montoTotal": 45000,
                                "fechaEmision": "2025-06-21T10:30:00",
                                "estado": "PAGADA",
                                "metodoPago": "TARJETA"
                            }
                            """)))
            @RequestBody Factura factura) {
        factura.setId(id);
        return facturaService.updateFactura(factura);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una factura", description = "Elimina una factura del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Factura eliminada exitosamente",
                    content = @Content(mediaType = "text/plain")),
            @ApiResponse(responseCode = "404", description = "Factura no encontrada", content = @Content)
    })
    public String deleteFacturaById(
            @Parameter(description = "ID de la factura a eliminar", example = "1", required = true)
            @PathVariable int id) {
        return facturaService.deleteFactura(id);
    }
}