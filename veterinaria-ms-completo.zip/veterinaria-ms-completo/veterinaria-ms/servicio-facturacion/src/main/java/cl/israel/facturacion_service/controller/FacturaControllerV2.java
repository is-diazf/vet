package cl.israel.facturacion_service.controller;

import cl.israel.facturacion_service.model.Factura;
import cl.israel.facturacion_service.service.FacturaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/facturas")
public class FacturaControllerV2 {

    private final FacturaService facturaService;

    public FacturaControllerV2(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    @GetMapping
    public List<Factura> getFacturas() {
        return facturaService.getFacturas();
    }

    @GetMapping("/{id}")
    public Factura getFacturaById(@PathVariable int id) {
        return facturaService.getFacturaById(id);
    }

    @PostMapping
    public Factura saveFactura(@RequestBody Factura factura) {
        return facturaService.saveFactura(factura);
    }

    @PutMapping("/{id}")
    public Factura updateFacturaById(@PathVariable int id, @RequestBody Factura factura) {
        factura.setId(id);
        return facturaService.updateFactura(factura);
    }

    @DeleteMapping("/{id}")
    public String deleteFacturaById(@PathVariable int id) {
        return facturaService.deleteFactura(id);
    }
}