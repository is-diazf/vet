package cl.israel.facturacion_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una factura")
public class Factura {

    @Schema(description = "ID único de la factura", example = "1", required = true)
    private int id;

    @Schema(description = "ID de la cita asociada", example = "1", required = true)
    private int idCita;

    @Schema(description = "Monto total de la factura", example = "45000", required = true)
    private double montoTotal;

    @Schema(description = "Fecha de emisión de la factura", example = "2025-06-21T10:30:00")
    private String fechaEmision;

    @Schema(description = "Estado de la factura", example = "PAGADA")
    private String estado;

    @Schema(description = "Método de pago", example = "EFECTIVO")
    private String metodoPago;
}