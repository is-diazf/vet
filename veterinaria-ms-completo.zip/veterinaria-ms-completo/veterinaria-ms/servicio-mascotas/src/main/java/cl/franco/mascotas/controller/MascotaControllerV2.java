package cl.franco.mascotas.controller;

import cl.franco.mascotas.model.Mascota;
import cl.franco.mascotas.service.MascotaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/mascotas")
public class MascotaControllerV2 {

    private final MascotaService mascotaService;

    public MascotaControllerV2(MascotaService mascotaService) {
        this.mascotaService = mascotaService;
    }

    @GetMapping
    public List<Mascota> getMascotas() {
        return mascotaService.getMascotas();
    }

    @GetMapping("/{id}")
    public Mascota getMascotaById(@PathVariable int id) {
        return mascotaService.getMascotaById(id);
    }

    @PostMapping
    public Mascota saveMascota(@RequestBody Mascota mascota) {
        return mascotaService.saveMascota(mascota);
    }

    @PutMapping("/{id}")
    public Mascota updateMascotaById(@PathVariable int id, @RequestBody Mascota mascota) {
        mascota.setId(id);
        return mascotaService.updateMascota(mascota);
    }

    @DeleteMapping("/{id}")
    public String deleteMascotaById(@PathVariable int id) {
        return mascotaService.deleteMascota(id);
    }
}