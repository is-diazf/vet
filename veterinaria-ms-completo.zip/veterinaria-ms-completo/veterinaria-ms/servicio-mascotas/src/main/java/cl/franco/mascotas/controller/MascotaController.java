package cl.franco.mascotas.controller;

import cl.franco.mascotas.model.Mascota;
import cl.franco.mascotas.service.MascotaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/mascotas")
@Tag(name = "Mascotas", description = "Operaciones relacionadas con las mascotas")
public class MascotaController {

    private final MascotaService mascotaService;

    public MascotaController(MascotaService mascotaService) {
        this.mascotaService = mascotaService;
    }

    @GetMapping
    @Operation(summary = "Obtener todas las mascotas", description = "Obtiene una lista de todas las mascotas registradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de mascotas obtenida exitosamente",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Mascota.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<Mascota> getMascotas() {
        return mascotaService.getMascotas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una mascota por ID", description = "Retorna una mascota específica basada en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Mascota encontrada",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Mascota.class))),
            @ApiResponse(responseCode = "404", description = "Mascota no encontrada", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public Mascota getMascotaById(
            @Parameter(description = "ID de la mascota a buscar", example = "1", required = true)
            @PathVariable int id) {
        return mascotaService.getMascotaById(id);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva mascota", description = "Agrega una nueva mascota al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Mascota creada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Mascota.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public Mascota saveMascota(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Mascota que se va a crear",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Mascota.class),
                    examples = @ExampleObject(name = "Ejemplo de mascota", value = """
                            {
                                "id": 1,
                                "nombre": "Firulais",
                                "raza": "Labrador",
                                "fechaNacimientoMascota": "2020-05-15"
                            }
                            """)))
            @RequestBody Mascota mascota) {
        return mascotaService.saveMascota(mascota);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una mascota existente", description = "Actualiza los datos de una mascota existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Mascota actualizada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Mascota.class))),
            @ApiResponse(responseCode = "404", description = "Mascota no encontrada", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public Mascota updateMascotaById(
            @Parameter(description = "ID de la mascota a actualizar", example = "1", required = true)
            @PathVariable int id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Mascota con los datos actualizados",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Mascota.class),
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "id": 1,
                                "nombre": "Firulais Actualizado",
                                "raza": "Golden Retriever",
                                "fechaNacimientoMascota": "2020-05-15"
                            }
                            """)))
            @RequestBody Mascota mascota) {
        mascota.setId(id);
        return mascotaService.updateMascota(mascota);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una mascota", description = "Elimina una mascota del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Mascota eliminada exitosamente",
                    content = @Content(mediaType = "text/plain")),
            @ApiResponse(responseCode = "404", description = "Mascota no encontrada", content = @Content)
    })
    public String deleteMascotaById(
            @Parameter(description = "ID de la mascota a eliminar", example = "1", required = true)
            @PathVariable int id) {
        return mascotaService.deleteMascota(id);
    }
}