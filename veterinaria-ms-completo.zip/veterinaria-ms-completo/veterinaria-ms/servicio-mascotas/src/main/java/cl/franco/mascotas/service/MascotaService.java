package cl.franco.mascotas.service;

import cl.franco.mascotas.model.Mascota;
import cl.franco.mascotas.repository.MascotaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MascotaService {

    private final MascotaRepository mascotaRepository;

    public MascotaService(MascotaRepository mascotaRepository) {
        this.mascotaRepository = mascotaRepository;
    }

    public List<Mascota> getMascotas() {
        return mascotaRepository.getMascotas();
    }

    public Mascota saveMascota(Mascota mascota) {
        return mascotaRepository.saveMascota(mascota);
    }

    public Mascota getMascotaById(int id) {
        return mascotaRepository.searchById(id);
    }

    public Mascota updateMascota(Mascota mascota) {
        return mascotaRepository.updateMascota(mascota);
    }

    public String deleteMascota(int id) {
        mascotaRepository.eliminar(id);
        return "Mascota eliminada correctamente";
    }
}
