package cl.franco.mascotas.repository;

import cl.franco.mascotas.model.Mascota;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class MascotaRepository {

    private List<Mascota> listaMascotas = new ArrayList<>();

    public List<Mascota> getMascotas() {
        return listaMascotas;
    }

    public Mascota searchById(int id) {
        for (Mascota mascota : listaMascotas) {
            if (mascota.getId() == id) {
                return mascota;
            }
        }
        return null;
    }

    public Mascota buscarPorNombre(String nombre) {
        for (Mascota mascota : listaMascotas) {
            if (mascota.getNombre().equals(nombre)) {
                return mascota;
            }
        }
        return null;
    }

    public Mascota saveMascota(Mascota mascota) {
        listaMascotas.add(mascota);
        return mascota;
    }

    public Mascota updateMascota(Mascota mascota) {
        int idPosicion = -1;

        for (int i = 0; i < listaMascotas.size(); i++) {
            if (listaMascotas.get(i).getId() == mascota.getId()) {
                idPosicion = i;
                break;
            }
        }

        if (idPosicion == -1) {
            return null;
        }

        Mascota mascotaExistente = listaMascotas.get(idPosicion);
        mascotaExistente.setId(mascota.getId());
        mascotaExistente.setNombre(mascota.getNombre());
        mascotaExistente.setRaza(mascota.getRaza());
        mascotaExistente.setFechaNacimientoMascota(mascota.getFechaNacimientoMascota());

        return mascotaExistente;
    }

    public void eliminar(int id) {
        listaMascotas.removeIf(x -> x.getId() == id);
    }
}