package cl.franco.mascotas.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa una mascota")
public class Mascota {

    @Schema(description = "ID único de la mascota", example = "1", required = true)
    private int id;

    @Schema(description = "Nombre de la mascota", example = "Firulais", required = true)
    private String nombre;

    @Schema(description = "Raza de la mascota", example = "Labrador")
    private String raza;

    @Schema(description = "Fecha de nacimiento de la mascota", example = "2020-05-15")
    private String fechaNacimientoMascota;
}