package cl.israel.citas.controller;

import cl.israel.citas.model.Citas;
import cl.israel.citas.service.CitaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/citas")
public class CitaControllerV2 {

    private final CitaService citaService;

    public CitaControllerV2(CitaService citaService) {
        this.citaService = citaService;
    }

    @GetMapping
    public List<Citas> getCitas() {
        return citaService.getCitas();
    }

    @GetMapping("/{id}")
    public Citas getCitaById(@PathVariable int id) {
        return citaService.getCitaById(id);
    }

    @GetMapping("/mascota/{nombreMascota}")
    public List<Citas> getCitasByMascota(@PathVariable String nombreMascota) {
        return citaService.buscarPorMascota(nombreMascota);
    }

    @GetMapping("/veterinario/{idVeterinario}")
    public List<Citas> getCitasByVeterinario(@PathVariable int idVeterinario) {
        return citaService.buscarPorVeterinario(idVeterinario);
    }

    @PostMapping
    public Citas saveCita(@RequestBody Citas cita) {
        return citaService.saveCita(cita);
    }

    @PutMapping("/{id}")
    public Citas updateCitaById(@PathVariable int id, @RequestBody Citas cita) {
        cita.setId(id);
        return citaService.updateCita(cita);
    }

    @DeleteMapping("/{id}")
    public String deleteCitaById(@PathVariable int id) {
        return citaService.deleteCita(id);
    }
}