package cl.israel.citas.controller;

import cl.israel.citas.model.Citas;
import cl.israel.citas.service.CitaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/citas")
@Tag(name = "Citas", description = "Operaciones relacionadas con las citas")
public class CitaController {

    private final CitaService citaService;

    public CitaController(CitaService citaService) {
        this.citaService = citaService;
    }

    @GetMapping
    @Operation(summary = "Obtener todas las citas", description = "Obtiene una lista de todas las citas registradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de citas obtenida exitosamente",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Citas.class)))),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public List<Citas> getCitas() {
        return citaService.getCitas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una cita por ID", description = "Retorna una cita específica basada en su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Cita encontrada",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Citas.class))),
            @ApiResponse(responseCode = "404", description = "Cita no encontrada", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    public Citas getCitaById(
            @Parameter(description = "ID de la cita a buscar", example = "1", required = true)
            @PathVariable int id) {
        return citaService.getCitaById(id);
    }

    @GetMapping("/mascota/{nombreMascota}")
    @Operation(summary = "Buscar citas por nombre de mascota", description = "Retorna todas las citas de una mascota específica.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Citas encontradas",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Citas.class)))),
            @ApiResponse(responseCode = "404", description = "No se encontraron citas", content = @Content)
    })
    public List<Citas> getCitasByMascota(
            @Parameter(description = "Nombre de la mascota", example = "Firulais", required = true)
            @PathVariable String nombreMascota) {
        return citaService.buscarPorMascota(nombreMascota);
    }

    @GetMapping("/veterinario/{idVeterinario}")
    @Operation(summary = "Buscar citas por ID de veterinario", description = "Retorna todas las citas de un veterinario específico.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Citas encontradas",
                    content = @Content(mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Citas.class)))),
            @ApiResponse(responseCode = "404", description = "No se encontraron citas", content = @Content)
    })
    public List<Citas> getCitasByVeterinario(
            @Parameter(description = "ID del veterinario", example = "1", required = true)
            @PathVariable int idVeterinario) {
        return citaService.buscarPorVeterinario(idVeterinario);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva cita", description = "Agrega una nueva cita al sistema.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Cita creada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Citas.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida (datos incorrectos)", content = @Content)
    })
    public Citas saveCita(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Cita que se va a crear",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Citas.class),
                    examples = @ExampleObject(name = "Ejemplo de cita", value = """
                            {
                                "id": 1,
                                "idVeterinario": 1,
                                "nombreMascota": "Firulais",
                                "razaMascota": "Labrador",
                                "nombreDueño": "Juan Pérez",
                                "telefonoDueño": "+56912345678",
                                "fechaCita": "2025-06-25",
                                "horaCita": "10:30",
                                "motivoCita": "Consulta general"
                            }
                            """)))
            @RequestBody Citas cita) {
        return citaService.saveCita(cita);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una cita existente", description = "Actualiza los datos de una cita existente por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Cita actualizada exitosamente",
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Citas.class))),
            @ApiResponse(responseCode = "404", description = "Cita no encontrada", content = @Content),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida", content = @Content)
    })
    public Citas updateCitaById(
            @Parameter(description = "ID de la cita a actualizar", example = "1", required = true)
            @PathVariable int id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Objeto Cita con los datos actualizados",
                    required = true,
                    content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Citas.class),
                    examples = @ExampleObject(name = "Ejemplo de actualización", value = """
                            {
                                "id": 1,
                                "idVeterinario": 1,
                                "nombreMascota": "Firulais",
                                "razaMascota": "Labrador",
                                "nombreDueño": "Juan Pérez",
                                "telefonoDueño": "+56912345678",
                                "fechaCita": "2025-06-26",
                                "horaCita": "11:00",
                                "motivoCita": "Consulta de seguimiento"
                            }
                            """)))
            @RequestBody Citas cita) {
        cita.setId(id);
        return citaService.updateCita(cita);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una cita", description = "Elimina una cita del sistema por su ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Cita eliminada exitosamente",
                    content = @Content(mediaType = "text/plain")),
            @ApiResponse(responseCode = "404", description = "Cita no encontrada", content = @Content)
    })
    public String deleteCitaById(
            @Parameter(description = "ID de la cita a eliminar", example = "1", required = true)
            @PathVariable int id) {
        return citaService.deleteCita(id);
    }
}