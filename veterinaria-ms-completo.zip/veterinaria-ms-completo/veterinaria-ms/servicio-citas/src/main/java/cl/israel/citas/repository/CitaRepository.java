package cl.israel.citas.repository;

import cl.israel.citas.model.Citas;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CitaRepository {

    private List<Citas> listaCitas = new ArrayList<>();

    public List<Citas> getCitas() {
        return listaCitas;
    }

    public Citas searchById(int id) {
        for (Citas cita : listaCitas) {
            if (cita.getId() == id) {
                return cita;
            }
        }
        return null;
    }

    public List<Citas> buscarPorMascota(String nombreMascota) {
        List<Citas> resultado = new ArrayList<>();
        for (Citas cita : listaCitas) {
            if (cita.getNombreMascota().equalsIgnoreCase(nombreMascota)) {
                resultado.add(cita);
            }
        }
        return resultado;
    }

    public List<Citas> buscarPorVeterinario(int idVeterinario) {
        List<Citas> resultado = new ArrayList<>();
        for (Citas cita : listaCitas) {
            if (cita.getIdVeterinario() == idVeterinario) {
                resultado.add(cita);
            }
        }
        return resultado;
    }

    public Citas saveCita(Citas cita) {
        listaCitas.add(cita);
        return cita;
    }

    public Citas updateCita(Citas cita) {
        int idPosicion = -1;
        for (int i = 0; i < listaCitas.size(); i++) {
            if (listaCitas.get(i).getId() == cita.getId()) {
                idPosicion = i;
                break;
            }
        }
        if (idPosicion == -1) {
            return null;
        }
        listaCitas.set(idPosicion, cita);
        return cita;
    }

    public void eliminar(int id) {
        listaCitas.removeIf(x -> x.getId() == id);
    }
}