package cl.israel.citas.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa una cita")
public class Citas {  // ← Nombre de la clase = Citas (con "s")

    @Schema(description = "ID único de la cita", example = "1", required = true)
    private int id;

    @Schema(description = "ID del veterinario", example = "1", required = true)
    private int idVeterinario;

    @Schema(description = "Nombre de la mascota", example = "Firulais", required = true)
    private String nombreMascota;

    @Schema(description = "Raza de la mascota", example = "Labrador")
    private String razaMascota;

    @Schema(description = "Nombre del dueño", example = "Juan Pérez", required = true)
    private String nombreDueño;

    @Schema(description = "Teléfono del dueño", example = "+56912345678", required = true)
    private String telefonoDueño;

    @Schema(description = "Fecha de la cita", example = "2025-06-25", required = true)
    private String fechaCita;

    @Schema(description = "Hora de la cita", example = "10:30", required = true)
    private String horaCita;

    @Schema(description = "Motivo de la cita", example = "Consulta general", required = true)
    private String motivoCita;
}