package cl.israel.citas.service;

import cl.israel.citas.model.Citas;
import cl.israel.citas.repository.CitaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitaService {

    private final CitaRepository citaRepository;

    public CitaService(CitaRepository citaRepository) {
        this.citaRepository = citaRepository;
    }

    public List<Citas> getCitas() {
        return citaRepository.getCitas();
    }

    public Citas saveCita(Citas cita) {
        return citaRepository.saveCita(cita);
    }

    public Citas getCitaById(int id) {
        return citaRepository.searchById(id);
    }

    public Citas updateCita(Citas cita) {
        return citaRepository.updateCita(cita);
    }

    public String deleteCita(int id) {
        citaRepository.eliminar(id);
        return "Cita eliminada correctamente";
    }

    public List<Citas> buscarPorMascota(String nombreMascota) {
        return citaRepository.buscarPorMascota(nombreMascota);
    }

    public List<Citas> buscarPorVeterinario(int idVeterinario) {
        return citaRepository.buscarPorVeterinario(idVeterinario);
    }
}