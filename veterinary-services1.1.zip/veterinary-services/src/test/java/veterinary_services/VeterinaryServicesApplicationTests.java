package veterinary_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeterinaryServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
