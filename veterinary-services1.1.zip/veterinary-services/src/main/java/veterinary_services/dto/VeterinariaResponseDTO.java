package veterinary_services.dto;

import lombok.Data;

@Data
public class VeterinariaResponseDTO {

    private Long id;
    private String nombre;
    private String direccion;
    private String telefono;
}
