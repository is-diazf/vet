package veterinary_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeterinaryServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeterinaryServicesApplication.class, args);
	}

}
