package veterinary_services.service;

import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.model.Veterinaria;
import veterinary_services.repository.VeterinariaRepository;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class VeterinariaService {

    private VeterinariaRepository veterinariaRepository;

    public VeterinariaResponseDTO obtenerVeterinaria(Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id)); 


        VeterinariaResponseDTO dto = new VeterinariaResponseDTO();
        dto.setId(veterinaria.getId());
        dto.setNombre(veterinaria.getNombre());
        dto.setDireccion(veterinaria.getDireccion());
        dto.setTelefono(veterinaria.getTelefono());

        return mapearADto(veterinaria);
        }

    public VeterinariaResponseDTO guardarVeterinaria(VeterinariaRequestDTO veterinariaRequestDTO) {
        Veterinaria veterinaria = new Veterinaria();
        veterinaria.setNombre(veterinariaRequestDTO.getNombre());
        veterinaria.setDireccion(veterinariaRequestDTO.getDireccion()); 
        veterinaria.setTelefono(veterinariaRequestDTO.getTelefono());
        
        Veterinaria veterinariaGuardada = veterinariaRepository.save(veterinaria);

        return mapToResponseDTO(veterinariaGuardada);
    }

        private VeterinariaResponseDTO mapToResponseDTO(Veterinaria veterinaria) {
            VeterinariaResponseDTO dto = new VeterinariaResponseDTO();
            dto.setId(veterinaria.getId());
            dto.setNombre(veterinaria.getNombre());
            dto.setDireccion(veterinaria.getDireccion());
            dto.setTelefono(veterinaria.getTelefono());
        
            return dto;
        }


        public List<VeterinariaResponseDTO> obtenerTodasLasVeterinarias() {
            List<Veterinaria> veterinarias = veterinariaRepository.findAll();
            return veterinarias.stream()
                .map(this::mapearADto)
                .collect(Collectors.toList());
        }

        public VeterinariaResponseDTO guardarVeterinaria(Veterinaria veterinara){
            Veterinaria veterinariaGuardada = veterinariaRepository.save(veterinara);
            return mapearADto(veterinariaGuardada);
        }

        public VeterinariaResponseDTO actualizarVeterinaria(Long id, Veterinaria detallesVeterinaria){
            //1.- Verificamos que la veterinaria exista
            Veterinaria veterinariaExistente = veterinariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
            //2.- Actualizamos los detalles
            veterinariaExistente.setNombre(detallesVeterinaria.getNombre());
            veterinariaExistente.setDireccion(detallesVeterinaria.getDireccion());
            veterinariaExistente.setTelefono(detallesVeterinaria.getTelefono());
            //3.- Guardamos los cambios
            Veterinaria veterinariaActualizada = veterinariaRepository.save(veterinariaExistente);
            return mapearADto(veterinariaActualizada);
        }

        private VeterinariaResponseDTO mapearADto(Veterinaria veterinaria) {
            VeterinariaResponseDTO dto = new VeterinariaResponseDTO();
            dto.setId(veterinaria.getId());
            dto.setNombre(veterinaria.getNombre());
            dto.setDireccion(veterinaria.getDireccion());
            dto.setTelefono(veterinaria.getTelefono());
        
            return dto;
        }        

}
