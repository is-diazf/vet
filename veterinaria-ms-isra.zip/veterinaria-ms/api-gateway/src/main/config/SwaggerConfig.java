package cl.israel.gateway.config;   // ← DEBE SER ESTE

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("API Gateway - Veterinaria")
                .version("1.0.0")
                .description("API Gateway para el sistema de microservicios de veterinaria"));
    }
}