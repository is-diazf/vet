package veterinary_services.repository;

import veterinary_services.model.Veterinaria;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface VeterinariaRepository extends JpaRepository<Veterinaria,Long> {
    List<Veterinaria> findByNombre(String nombre);
    List<Veterinaria> findByDireccionContaining(String direccion);
}