package veterinary_services.controller;

import veterinary_services.model.Veterinaria;
import veterinary_services.service.VeterinariaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/veterinarias")
@RequiredArgsConstructor
public class VeterinariaController {

    private final VeterinariaService veterinariaService;

    @GetMapping
    public List<Veterinaria> listarVeterinarias() {
        return veterinariaService.listarTodas();
    }

    @GetMapping("/{id}")
    public Veterinaria obtenerVeterinaria(@PathVariable Long id) {
        return veterinariaService.obtenerVeterinaria(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Veterinaria guardarVeterinaria(@RequestBody Veterinaria veterinaria) {
        return veterinariaService.guardarVeterinaria(veterinaria);
    }
}