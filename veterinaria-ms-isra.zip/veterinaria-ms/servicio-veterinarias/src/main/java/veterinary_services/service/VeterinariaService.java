package veterinary_services.service;

import veterinary_services.model.Veterinaria;
import veterinary_services.repository.VeterinariaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VeterinariaService {

    private final VeterinariaRepository veterinariaRepository;

    public List<Veterinaria> listarTodas() {
        return veterinariaRepository.findAll();
    }

    public Veterinaria obtenerVeterinaria(Long id) {
        return veterinariaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
    }

    public Veterinaria guardarVeterinaria(Veterinaria veterinaria) {
        return veterinariaRepository.save(veterinaria);
    }
}