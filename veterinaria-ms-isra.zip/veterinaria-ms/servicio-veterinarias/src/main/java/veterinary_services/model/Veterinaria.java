package veterinary_services.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "veterinarias")
@Schema(description = "Representa una clínica veterinaria en el sistema")
public class Veterinaria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la veterinaria", example = "1")
    private Long id;

    @Schema(description = "Nombre de la clínica", example = "Veterinaria Central")
    private String nombre;

    @Schema(description = "Dirección de la clínica", example = "Av. Principal 123")
    private String direccion;  // ← Corregido: sin acento

    @Schema(description = "Teléfono de contacto", example = "91234567")
    private String telefono;
}